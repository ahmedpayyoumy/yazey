<?php

namespace App\Http\Controllers;

use App\ContactFormReply;
use Illuminate\Http\Request;

class ContactFormReplyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ContactFormReply  $contactFormReply
     * @return \Illuminate\Http\Response
     */
    public function show(ContactFormReply $contactFormReply)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ContactFormReply  $contactFormReply
     * @return \Illuminate\Http\Response
     */
    public function edit(ContactFormReply $contactFormReply)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ContactFormReply  $contactFormReply
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ContactFormReply $contactFormReply)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ContactFormReply  $contactFormReply
     * @return \Illuminate\Http\Response
     */
    public function destroy(ContactFormReply $contactFormReply)
    {
        //
    }
}
