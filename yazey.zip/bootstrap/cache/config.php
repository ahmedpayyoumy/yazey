<?php return array (
  'activitylog' => 
  array (
    'enabled' => true,
    'delete_records_older_than_days' => 365,
    'default_log_name' => 'default',
    'default_auth_driver' => NULL,
    'subject_returns_soft_deleted_models' => false,
    'activity_model' => 'Spatie\\Activitylog\\Models\\Activity',
    'table_name' => 'activity_log',
    'database_connection' => NULL,
  ),
  'app' => 
  array (
    'name' => 'Yazey App',
    'force_https' => true,
    'env' => 'local',
    'debug' => true,
    'url' => 'https://app.yazey.com/',
    'asset_url' => NULL,
    'timezone' => 'CET',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:fKHWS2z15nUIIi2VK7GhzDyFfZ1R6sWo2Hh+V++OYMY=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Barryvdh\\Debugbar\\ServiceProvider',
      23 => 'App\\Providers\\MetronicServiceProvider',
      24 => 'App\\Providers\\AppServiceProvider',
      25 => 'App\\Providers\\AuthServiceProvider',
      26 => 'App\\Providers\\EventServiceProvider',
      27 => 'App\\Providers\\HorizonServiceProvider',
      28 => 'App\\Providers\\RouteServiceProvider',
      29 => 'App\\Providers\\ViewServiceProvider',
      30 => 'Yoeunes\\Toastr\\ToastrServiceProvider',
      31 => 'Yajra\\DataTables\\DataTablesServiceProvider',
      32 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      33 => 'Laravel\\Socialite\\SocialiteServiceProvider',
      34 => 'Rap2hpoutre\\LaravelLogViewer\\LaravelLogViewerServiceProvider',
      35 => 'ESP\\QrCode\\QrCodeServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
      'Metronic' => 'App\\Classes\\Theme\\Metronic',
      'Menu' => 'App\\Classes\\Theme\\Menu',
      'DataTables' => 'Yajra\\DataTables\\Facades\\DataTables',
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'backup' => 
  array (
    'backup' => 
    array (
      'name' => 'Yazey App',
      'source' => 
      array (
        'files' => 
        array (
          'include' => 
          array (
            0 => '/media/bayyou/Storage/windows/Work/Yazey',
          ),
          'exclude' => 
          array (
            0 => '/media/bayyou/Storage/windows/Work/Yazey/vendor',
            1 => '/media/bayyou/Storage/windows/Work/Yazey/node_modules',
          ),
          'follow_links' => false,
          'ignore_unreadable_directories' => false,
          'relative_path' => NULL,
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'database_dump_compressor' => NULL,
      'database_dump_file_extension' => '',
      'destination' => 
      array (
        'filename_prefix' => '',
        'disks' => 
        array (
          0 => 'backup',
        ),
      ),
      'temporary_directory' => '/media/bayyou/Storage/windows/Work/Yazey/storage/app/backup-temp',
      'password' => NULL,
      'encryption' => 'default',
    ),
    'notifications' => 
    array (
      'notifications' => 
      array (
        'Spatie\\Backup\\Notifications\\Notifications\\BackupHasFailed' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\UnhealthyBackupWasFound' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupHasFailed' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\BackupWasSuccessful' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\HealthyBackupWasFound' => 
        array (
          0 => 'mail',
        ),
        'Spatie\\Backup\\Notifications\\Notifications\\CleanupWasSuccessful' => 
        array (
          0 => 'mail',
        ),
      ),
      'notifiable' => 'Spatie\\Backup\\Notifications\\Notifiable',
      'mail' => 
      array (
        'to' => 'your@example.com',
        'from' => 
        array (
          'address' => 'ash@yazey.com',
          'name' => 'Ash From Yazey',
        ),
      ),
      'slack' => 
      array (
        'webhook_url' => '',
        'channel' => NULL,
        'username' => NULL,
        'icon' => NULL,
      ),
    ),
    'monitor_backups' => 
    array (
      0 => 
      array (
        'name' => 'Yazey App',
        'disks' => 
        array (
          0 => 'backup',
        ),
        'health_checks' => 
        array (
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumAgeInDays' => 1,
          'Spatie\\Backup\\Tasks\\Monitor\\HealthChecks\\MaximumStorageInMegabytes' => 5000,
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'default_strategy' => 
      array (
        'keep_all_backups_for_days' => 7,
        'keep_daily_backups_for_days' => 16,
        'keep_weekly_backups_for_weeks' => 8,
        'keep_monthly_backups_for_months' => 4,
        'keep_yearly_backups_for_years' => 2,
        'delete_oldest_backups_when_using_more_megabytes_than' => 5000,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'ap1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/media/bayyou/Storage/windows/Work/Yazey/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
    ),
    'prefix' => 'yazey_app_cache',
  ),
  'chunk-upload' => 
  array (
    'storage' => 
    array (
      'chunks' => 'chunks',
      'disk' => 'local',
    ),
    'clear' => 
    array (
      'timestamp' => '-3 HOURS',
      'schedule' => 
      array (
        'enabled' => true,
        'cron' => '25 * * * *',
      ),
    ),
    'chunk' => 
    array (
      'name' => 
      array (
        'use' => 
        array (
          'session' => true,
          'browser' => false,
        ),
      ),
    ),
    'handlers' => 
    array (
      'custom' => 
      array (
      ),
      'override' => 
      array (
      ),
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'yazey_db',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'yazey_db',
        'username' => 'root',
        'password' => '01022844956aH',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => false,
        'engine' => NULL,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'yazey_db',
        'username' => 'root',
        'password' => '01022844956aH',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'yazey_db',
        'username' => 'root',
        'password' => '01022844956aH',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
      'cache' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 1,
      ),
      'horizon' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
        'options' => 
        array (
          'prefix' => 'yazey_app_horizon:',
        ),
      ),
    ),
  ),
  'database-schedule' => 
  array (
    'table' => 
    array (
      'schedules' => 'schedules',
      'schedule_histories' => 'schedule_histories',
    ),
    'model' => 'RobersonFaria\\DatabaseSchedule\\Models\\Schedule',
    'timezone' => 'CET',
    'middleware' => 'web',
    'guard' => 'web',
    'restricted_access' => true,
    'enable_groups' => false,
    'cache' => 
    array (
      'store' => 'file',
      'key' => 'yazey_app_database_schedule_',
      'enabled' => false,
    ),
    'route' => 
    array (
      'prefix' => 'schedule',
    ),
    'default_ordering' => 'created_at',
    'default_ordering_direction' => 'DESC',
    'per_page' => 10,
    'commands' => 
    array (
      'exclude' => 
      array (
        0 => 'help',
        1 => 'list',
        2 => 'test',
        3 => 'down',
        4 => 'up',
        5 => 'env',
        6 => 'serve',
        7 => 'tinker',
        8 => 'clear-compiled',
        9 => 'key:generate',
        10 => 'package:discover',
        11 => 'storage:link',
        12 => 'notifications:table',
        13 => 'session:table',
        14 => 'stub:publish',
        15 => 'vendor:publish',
        16 => 'route:*',
        17 => 'event:*',
        18 => 'migrate:*',
        19 => 'cache:*',
        20 => 'auth:*',
        21 => 'config:*',
        22 => 'db:*',
        23 => 'optimize*',
        24 => 'make:*',
        25 => 'queue:*',
        26 => 'schedule:*',
        27 => 'view:*',
      ),
    ),
    'tool-help-cron-expression' => 
    array (
      'enable' => true,
      'url' => 'https://crontab.cronhub.io/',
    ),
  ),
  'datatables' => 
  array (
    'search' => 
    array (
      'smart' => true,
      'multi_term' => true,
      'case_insensitive' => true,
      'use_wildcards' => false,
      'starts_with' => false,
    ),
    'index_column' => 'DT_RowIndex',
    'engines' => 
    array (
      'eloquent' => 'Yajra\\DataTables\\EloquentDataTable',
      'query' => 'Yajra\\DataTables\\QueryDataTable',
      'collection' => 'Yajra\\DataTables\\CollectionDataTable',
      'resource' => 'Yajra\\DataTables\\ApiResourceDataTable',
    ),
    'builders' => 
    array (
    ),
    'nulls_last_sql' => ':column :direction NULLS LAST',
    'error' => NULL,
    'columns' => 
    array (
      'excess' => 
      array (
        0 => 'rn',
        1 => 'row_num',
      ),
      'escape' => '*',
      'raw' => 
      array (
        0 => 'action',
      ),
      'blacklist' => 
      array (
        0 => 'password',
        1 => 'remember_token',
      ),
      'whitelist' => '*',
    ),
    'json' => 
    array (
      'header' => 
      array (
      ),
      'options' => 0,
    ),
  ),
  'debug-server' => 
  array (
    'host' => 'tcp://127.0.0.1:9912',
  ),
  'debugbar' => 
  array (
    'enabled' => true,
    'except' => 
    array (
      0 => 'api*',
    ),
    'storage' => 
    array (
      'enabled' => true,
      'driver' => 'file',
      'path' => '/media/bayyou/Storage/windows/Work/Yazey/storage/debugbar',
      'connection' => NULL,
      'provider' => '',
    ),
    'editor' => 'phpstorm',
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'include_vendors' => true,
    'capture_ajax' => true,
    'add_ajax_timing' => false,
    'error_handler' => false,
    'clockwork' => false,
    'collectors' => 
    array (
      'phpinfo' => true,
      'messages' => true,
      'time' => true,
      'memory' => true,
      'exceptions' => true,
      'log' => true,
      'db' => true,
      'views' => true,
      'route' => true,
      'auth' => false,
      'gate' => true,
      'session' => true,
      'symfony_request' => true,
      'mail' => true,
      'laravel' => false,
      'events' => false,
      'default_request' => false,
      'logs' => false,
      'files' => false,
      'config' => false,
      'cache' => false,
      'models' => true,
    ),
    'options' => 
    array (
      'auth' => 
      array (
        'show_name' => true,
      ),
      'db' => 
      array (
        'with_params' => true,
        'backtrace' => true,
        'timeline' => false,
        'explain' => 
        array (
          'enabled' => false,
          'types' => 
          array (
            0 => 'SELECT',
          ),
        ),
        'hints' => true,
      ),
      'mail' => 
      array (
        'full_log' => false,
      ),
      'views' => 
      array (
        'data' => false,
      ),
      'route' => 
      array (
        'label' => true,
      ),
      'logs' => 
      array (
        'file' => NULL,
      ),
      'cache' => 
      array (
        'values' => true,
      ),
    ),
    'inject' => true,
    'route_prefix' => '_debugbar',
    'route_domain' => NULL,
    'theme' => 'auto',
    'debug_backtrace_limit' => 50,
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'driver' => 'memory',
      'batch' => 
      array (
        'memory_limit' => 60000,
      ),
      'illuminate' => 
      array (
        'store' => NULL,
      ),
    ),
    'transactions' => 
    array (
      'handler' => 'db',
    ),
    'temporary_files' => 
    array (
      'local_path' => '/media/bayyou/Storage/windows/Work/Yazey/storage/framework/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
  ),
  'facebook' => 
  array (
    'app_id' => '630037578026405',
    'app_secret' => '00ade31e23e50ee8274c69c3c7dec85f',
    'app_version' => 'v12.0',
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/media/bayyou/Storage/windows/Work/Yazey/storage/app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/media/bayyou/Storage/windows/Work/Yazey/storage/app/public',
        'url' => 'https://app.yazey.com//storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
        'url' => NULL,
      ),
      'backup' => 
      array (
        'driver' => 'local',
        'root' => '/media/bayyou/Storage/windows/Work/Yazey/storage/app/backup',
      ),
    ),
  ),
  'flare' => 
  array (
    'key' => NULL,
    'reporting' => 
    array (
      'anonymize_ips' => true,
      'collect_git_information' => false,
      'report_queries' => true,
      'maximum_number_of_collected_queries' => 200,
      'report_query_bindings' => true,
      'report_view_data' => true,
      'grouping_type' => NULL,
    ),
    'send_logs_as_events' => true,
    'censor_request_body_fields' => 
    array (
      0 => 'password',
    ),
  ),
  'google2fa' => 
  array (
    'enabled' => true,
    'lifetime' => 0,
    'keep_alive' => true,
    'auth' => 'auth',
    'guard' => '',
    'session_var' => 'google2fa',
    'otp_input' => 'one_time_password',
    'window' => 1,
    'forbid_old_passwords' => false,
    'otp_secret_column' => 'google2fa_secret',
    'view' => '2fa.2fa_verify',
    'error_messages' => 
    array (
      'wrong_otp' => 'The \'One Time Password\' typed was wrong.',
      'cannot_be_empty' => 'One Time Password cannot be empty.',
      'unknown' => 'An unknown error has occurred. Please try again.',
    ),
    'throw_exceptions' => true,
    'qrcode_image_backend' => 'svg',
  ),
  'googleanalytics' => 
  array (
    'app_id' => '738851485674-llrhd21nel36icfns5b0lohgpb30h8kl.apps.googleusercontent.com',
    'app_secret' => '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',
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'horizon' => 
  array (
    'domain' => NULL,
    'path' => 'horizon',
    'use' => 'default',
    'prefix' => 'yazey_app_horizon:',
    'middleware' => 
    array (
      0 => 'web',
    ),
    'waits' => 
    array (
      'redis:default' => 6000,
    ),
    'trim' => 
    array (
      'recent' => 600,
      'pending' => 600,
      'completed' => 600,
      'recent_failed' => 10080,
      'failed' => 10080,
      'monitored' => 10080,
    ),
    'metrics' => 
    array (
      'trim_snapshots' => 
      array (
        'job' => 24,
        'queue' => 24,
      ),
    ),
    'fast_termination' => false,
    'memory_limit' => 64,
    'environments' => 
    array (
      'production' => 
      array (
        'supervisor-1' => 
        array (
          'connection' => 'redis',
          'queue' => 
          array (
            0 => 'crawl_facebook_post',
            1 => 'crawl_user_history_conversion',
            2 => 'default',
            3 => 'send_message_portal',
            4 => 'schedule_broadcast_job',
            5 => 'schedule_sequence_job',
            6 => 'crawl_facebook_ads_set',
            7 => 'crawl_facebook_ads',
            8 => 'send_message_broadcast_personal_0',
            9 => 'send_message_broadcast_personal_1',
            10 => 'send_message_broadcast_personal_2',
            11 => 'send_message_broadcast_personal_3',
            12 => 'send_message_broadcast_personal_4',
            13 => 'send_message_broadcast_personal_5',
          ),
          'balance' => 'simple',
          'processes' => 10,
          'tries' => 1,
          'timeout' => 900,
        ),
      ),
      'local' => 
      array (
        'supervisor-1' => 
        array (
          'connection' => 'redis',
          'queue' => 
          array (
            0 => 'crawl_facebook_post',
            1 => 'crawl_user_history_conversion',
            2 => 'default',
            3 => 'send_message_portal',
            4 => 'schedule_broadcast_job',
            5 => 'schedule_sequence_job',
            6 => 'crawl_facebook_ads_set',
            7 => 'crawl_facebook_ads',
            8 => 'send_message_broadcast_personal_0',
            9 => 'send_message_broadcast_personal_1',
            10 => 'send_message_broadcast_personal_2',
            11 => 'send_message_broadcast_personal_3',
            12 => 'send_message_broadcast_personal_4',
            13 => 'send_message_broadcast_personal_5',
          ),
          'balance' => 'simple',
          'processes' => 10,
          'tries' => 1,
          'timeout' => 900,
        ),
      ),
    ),
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'light',
    'enable_share_button' => true,
    'register_commands' => false,
    'ignored_solution_providers' => 
    array (
      0 => 'Facade\\Ignition\\SolutionProviders\\MissingPackageSolutionProvider',
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => '',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
  ),
  'layout' => 
  array (
    'self' => 
    array (
      'layout' => 'default',
      'rtl' => false,
    ),
    'js' => 
    array (
      'breakpoints' => 
      array (
        'sm' => 576,
        'md' => 768,
        'lg' => 992,
        'xl' => 1200,
        'xxl' => 1200,
      ),
      'colors' => 
      array (
        'theme' => 
        array (
          'base' => 
          array (
            'white' => '#ffffff',
            'primary' => '#6993FF',
            'secondary' => '#E5EAEE',
            'success' => '#1BC5BD',
            'info' => '#8950FC',
            'warning' => '#FFA800',
            'danger' => '#F64E60',
            'light' => '#F3F6F9',
            'dark' => '#212121',
          ),
          'light' => 
          array (
            'white' => '#ffffff',
            'primary' => '#E1E9FF',
            'secondary' => '#ECF0F3',
            'success' => '#C9F7F5',
            'info' => '#EEE5FF',
            'warning' => '#FFF4DE',
            'danger' => '#FFE2E5',
            'light' => '#F3F6F9',
            'dark' => '#D6D6E0',
          ),
          'inverse' => 
          array (
            'white' => '#ffffff',
            'primary' => '#ffffff',
            'secondary' => '#212121',
            'success' => '#ffffff',
            'info' => '#ffffff',
            'warning' => '#ffffff',
            'danger' => '#ffffff',
            'light' => '#464E5F',
            'dark' => '#ffffff',
          ),
        ),
        'gray' => 
        array (
          'gray-100' => '#F3F6F9',
          'gray-200' => '#ECF0F3',
          'gray-300' => '#E5EAEE',
          'gray-400' => '#D6D6E0',
          'gray-500' => '#B5B5C3',
          'gray-600' => '#80808F',
          'gray-700' => '#464E5F',
          'gray-800' => '#1B283F',
          'gray-900' => '#212121',
        ),
      ),
      'font-family' => 'Poppins',
    ),
    'page-loader' => 
    array (
      'type' => '',
    ),
    'header' => 
    array (
      'self' => 
      array (
        'display' => true,
        'width' => 'fluid',
        'theme' => 'light',
        'fixed' => 
        array (
          'desktop' => true,
          'mobile' => true,
        ),
      ),
      'menu' => 
      array (
        'self' => 
        array (
          'display' => true,
          'layout' => 'default',
          'root-arrow' => false,
        ),
        'desktop' => 
        array (
          'arrow' => true,
          'toggle' => 'click',
          'submenu' => 
          array (
            'theme' => 'light',
            'arrow' => true,
          ),
        ),
        'mobile' => 
        array (
          'submenu' => 
          array (
            'theme' => 'dark',
            'accordion' => true,
          ),
        ),
      ),
    ),
    'subheader' => 
    array (
      'display' => false,
      'displayDesc' => true,
      'layout' => 'subheader-v1',
      'fixed' => true,
      'width' => 'fluid',
      'clear' => false,
      'layouts' => 
      array (
        'subheader-v1' => 'Subheader v1',
        'subheader-v2' => 'Subheader v2',
        'subheader-v3' => 'Subheader v3',
        'subheader-v4' => 'Subheader v4',
      ),
      'style' => 'solid',
    ),
    'content' => 
    array (
      'width' => 'fluid',
      'extended' => false,
    ),
    'brand' => 
    array (
      'self' => 
      array (
        'theme' => 'dark',
      ),
    ),
    'aside' => 
    array (
      'self' => 
      array (
        'theme' => 'dark',
        'display' => true,
        'fixed' => true,
        'minimize' => 
        array (
          'toggle' => true,
          'default' => false,
        ),
      ),
      'menu' => 
      array (
        'dropdown' => false,
        'scroll' => false,
        'submenu' => 
        array (
          'accordion' => true,
          'dropdown' => 
          array (
            'arrow' => true,
            'hover-timeout' => 500,
          ),
        ),
      ),
    ),
    'footer' => 
    array (
      'width' => 'fluid',
      'fixed' => false,
    ),
    'extras' => 
    array (
      'search' => 
      array (
        'display' => false,
        'layout' => 'dropdown',
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'notifications' => 
      array (
        'display' => false,
        'layout' => 'dropdown',
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'quick-actions' => 
      array (
        'display' => false,
        'layout' => 'dropdown',
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'user' => 
      array (
        'display' => true,
        'layout' => 'offcanvas',
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'languages' => 
      array (
        'display' => false,
      ),
      'cart' => 
      array (
        'display' => false,
        'dropdown' => 
        array (
          'style' => 'dark',
        ),
      ),
      'quick-panel' => 
      array (
        'display' => false,
        'offcanvas' => 
        array (
          'direction' => 'right',
        ),
      ),
      'chat' => 
      array (
        'display' => false,
      ),
      'toolbar' => 
      array (
        'display' => false,
      ),
      'scrolltop' => 
      array (
        'display' => true,
      ),
    ),
    'resources' => 
    array (
      'favicon' => 'media/img/logo/favicon.ico',
      'fonts' => 
      array (
        'google' => 
        array (
          'families' => 
          array (
            0 => 'Poppins:300,400,500,600,700',
          ),
        ),
      ),
      'css' => 
      array (
        0 => 'plugins/global/plugins.bundle.css',
        1 => 'plugins/custom/prismjs/prismjs.bundle.css',
        2 => 'css/style.bundle.css',
      ),
      'js' => 
      array (
        0 => 'plugins/global/plugins.bundle.js',
        1 => 'plugins/custom/prismjs/prismjs.bundle.js',
        2 => 'js/scripts.bundle.js',
      ),
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'daily',
        ),
        'ignore_exceptions' => false,
        'permission' => 438,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => '/media/bayyou/Storage/windows/Work/Yazey/storage/logs/laravel.log',
        'level' => 'debug',
        'permission' => 438,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => '/media/bayyou/Storage/windows/Work/Yazey/storage/logs/laravel.log',
        'level' => 'debug',
        'permission' => 438,
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'permission' => 438,
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'permission' => 438,
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
    ),
  ),
  'logviewer' => 
  array (
    'max_file_size' => 52428800,
    'pattern' => '*.log',
    'storage_path' => '/media/bayyou/Storage/windows/Work/Yazey/storage/logs',
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.sendgrid.net',
    'port' => '587',
    'from' => 
    array (
      'address' => 'ash@yazey.com',
      'name' => 'Ash From Yazey',
    ),
    'encryption' => 'tls',
    'username' => 'apikey',
    'password' => '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',
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/media/bayyou/Storage/windows/Work/Yazey/resources/views/vendor/mail',
      ),
    ),
    'log_channel' => NULL,
  ),
  'menu_aside' => 
  array (
    'items' => 
    array (
      0 => 
      array (
        'title' => 'Yazey Dashboard',
        'root' => true,
        'icon' => 'media/svg/icons/Shopping/Chart-bar3.svg',
        'page' => '/dashboard',
        'new-tab' => false,
      ),
      1 => 
      array (
        'title' => 'Connect Data',
        'root' => true,
        'icon' => 'media/svg/icons/General/Settings-1.svg',
        'page' => 'connect-data',
        'new-tab' => false,
        'sub_pages' => 
        array (
          0 => 'connect-data',
        ),
      ),
      2 => 
      array (
        'title' => 'Agency Spy',
        'root' => true,
        'icon' => 'media/svg/icons/General/AGENCY.svg',
        'page' => 'agency-spy',
        'new-tab' => false,
        'sub_pages' => 
        array (
          0 => 'agency-spy',
        ),
      ),
      3 => 
      array (
        'title' => 'My Profile',
        'root' => true,
        'icon' => 'media/svg/icons/General/User.svg',
        'page' => '/my-profile',
        'new-tab' => false,
      ),
    ),
  ),
  'menu_aside_admin' => 
  array (
    'items' => 
    array (
      0 => 
      array (
        'title' => 'Yazey Dashboard',
        'root' => true,
        'icon' => 'media/svg/icons/Shopping/Chart-bar3.svg',
        'page' => '/dashboard',
        'new-tab' => false,
      ),
      1 => 
      array (
        'title' => 'Do Synchronization',
        'root' => true,
        'icon' => 'media/svg/icons/General/Settings-2.svg',
        'page' => '#',
        'new-tab' => false,
        'custom-class' => 'connect_data',
      ),
      2 => 
      array (
        'title' => 'Connect Data',
        'root' => true,
        'icon' => 'media/svg/icons/General/Settings-1.svg',
        'page' => 'connect-data',
        'new-tab' => false,
        'sub_pages' => 
        array (
          0 => 'connect-data',
        ),
      ),
      3 => 
      array (
        'title' => 'Agency Spy',
        'root' => true,
        'icon' => 'media/svg/icons/General/AGENCY.svg',
        'page' => 'agency-spy',
        'new-tab' => false,
        'sub_pages' => 
        array (
          0 => 'agency-spy',
        ),
      ),
      4 => 
      array (
        'title' => 'My Profile',
        'root' => true,
        'icon' => 'media/svg/icons/General/User.svg',
        'page' => '/my-profile',
        'new-tab' => false,
      ),
      5 => 
      array (
        'title' => 'Users',
        'root' => true,
        'icon' => 'media/svg/icons/General/User.svg',
        'page' => '/users',
        'new-tab' => false,
      ),
      6 => 
      array (
        'title' => 'Billing',
        'root' => true,
        'icon' => 'media/svg/icons/Shopping/Wallet2.svg',
        'page' => '/billing',
        'new-tab' => false,
      ),
    ),
  ),
  'menu_header' => 
  array (
    'items' => 
    array (
      0 => 
      array (
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 900,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 3600,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'queue-monitor' => 
  array (
    'table' => 'queue_monitor',
    'connection' => NULL,
    'model' => 'romanzipp\\QueueMonitor\\Models\\Monitor',
    'db_max_length_exception' => 4294967295,
    'db_max_length_exception_message' => 65535,
    'ui' => 
    array (
      'per_page' => 35,
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => 'pk_test_51JyfgcEC0khrmilEN7gUO0NHGuZ3pqNZZiKmYk8jhCNrXRocKY30ybDfaAsbPOPc4SxsYsL8AXInHCFl9Db5DrWC00yS1EX8Sm',
      'secret' => 'sk_test_51JyfgcEC0khrmilEZwyvZDgvFomUmOJzu8gdgBjKyQXz8zTpVPxylRgnQtV7XkVUhjcOxpCzScPdSyy9zzXSJpCg00ZrOhN40w',
      'webhook' => 
      array (
        'secret' => NULL,
        'tolerance' => 300,
      ),
    ),
    'google' => 
    array (
      'client_id' => '818440943722-o2n030vagds810191skdqoqlhnrsq2bl.apps.googleusercontent.com',
      'client_secret' => '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',
      'redirect' => 'https://app.yazey.com/auth/google/callback',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/media/bayyou/Storage/windows/Work/Yazey/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'yazey_app_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
  'toastr' => 
  array (
    'maxItems' => NULL,
    'options' => 
    array (
      'closeButton' => true,
      'closeClass' => 'toast-close-button',
      'closeDuration' => 300,
      'closeEasing' => 'swing',
      'closeHtml' => '<button><i class="icon-off"></i></button>',
      'closeMethod' => 'fadeOut',
      'closeOnHover' => true,
      'containerId' => 'toast-container',
      'debug' => false,
      'escapeHtml' => false,
      'extendedTimeOut' => 10000,
      'hideDuration' => 1000,
      'hideEasing' => 'linear',
      'hideMethod' => 'fadeOut',
      'iconClass' => 'toast-info',
      'iconClasses' => 
      array (
        'error' => 'toast-error',
        'info' => 'toast-info',
        'success' => 'toast-success',
        'warning' => 'toast-warning',
      ),
      'messageClass' => 'toast-message',
      'newestOnTop' => false,
      'onHidden' => NULL,
      'onShown' => NULL,
      'positionClass' => 'toast-top-right',
      'preventDuplicates' => true,
      'progressBar' => true,
      'progressClass' => 'toast-progress',
      'rtl' => false,
      'showDuration' => 300,
      'showEasing' => 'swing',
      'showMethod' => 'fadeIn',
      'tapToDismiss' => true,
      'target' => 'body',
      'timeOut' => 5000,
      'titleClass' => 'toast-title',
      'toastClass' => 'toast',
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 94,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/media/bayyou/Storage/windows/Work/Yazey/resources/views',
    ),
    'compiled' => '/media/bayyou/Storage/windows/Work/Yazey/storage/framework/views',
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'sitemap' => 
  array (
    'guzzle_options' => 
    array (
      'cookies' => true,
      'connect_timeout' => 10,
      'timeout' => 10,
      'allow_redirects' => false,
    ),
    'execute_javascript' => false,
    'chrome_binary_path' => NULL,
    'crawl_profile' => 'Spatie\\Sitemap\\Crawler\\Profile',
  ),
);
