# ESP\QRCode
## QRCode Management

```
composer update
php artisan vendor:publish --tag=qrcode-views
```
