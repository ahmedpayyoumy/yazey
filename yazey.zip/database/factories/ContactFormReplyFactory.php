<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ContactFormReply;
use Faker\Generator as Faker;

$factory->define(ContactFormReply::class, function (Faker $faker) {
    return [
        //
    ];
});
