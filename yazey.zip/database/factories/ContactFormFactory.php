<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ContactForm;
use Faker\Generator as Faker;

$factory->define(ContactForm::class, function (Faker $faker) {
    return [
        //
    ];
});
