<?php

// return [
//     'app_id' => env('FB_APP_ID', '298248732231598'),
//     'app_secret' => env('FB_APP_SECRET', '710c9bdcd38d2b8bbacdc3ca16cd8e3f'),
//     'app_version' => env('FB_DEFAULT_GRAPH_VERSION', 'v12.0')
// ];


return [
    'app_id' => env('FB_APP_ID', '630037578026405'),
    'app_secret' => env('FB_APP_SECRET', '00ade31e23e50ee8274c69c3c7dec85f'),
    'app_version' => env('FB_DEFAULT_GRAPH_VERSION', 'v12.0')
];
