<?php

// return [
//     'app_id' => env('GG_ANALYTICS_APP_ID', '464064475934-qhei62tkqapi9296pd5jcmksf0mng6nn.apps.googleusercontent.com'),
//     'app_secret' => env('GG_ANALYTICS_APP_SECRET', 'JcYx0aS5qhGBtUNUH7ynlP23'),
// ];


return [
    'app_id' => env('GG_ANALYTICS_APP_ID', '738851485674-llrhd21nel36icfns5b0lohgpb30h8kl.apps.googleusercontent.com'),
    'app_secret' => env('GG_ANALYTICS_APP_SECRET', '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'),
];
